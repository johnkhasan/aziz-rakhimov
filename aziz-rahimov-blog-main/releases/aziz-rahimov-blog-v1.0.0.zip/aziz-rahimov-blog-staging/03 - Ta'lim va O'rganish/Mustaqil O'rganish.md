---
tags:
  - talim
  - rivojlanish
  - amaliy
---

# Mustaqil O'rganish

O'z-o'zini o'rgatish, intizom va bilimni amalda qo'llash haqida Aziz Rahimovning qarashlari.

Umumiy kontekst: [[Ta'lim va O'rganish]] · [[Shaxsiy Rivojlanish]]

---

## Intizom — ma'lumot emas, muammo

- "O'zim ingliz tilini o'rgana olamanmi? Ha." — marketing, biznes, IT ham o'rgatilishi mumkin. Muammo axborot emas — **intizom** (Post 165)
- "Menga hech kim o'rgatmagan" — bu bahona emas. Faqat siz o'zingizni o'rgata olasiz (Post 246)

## Soatlar va natija: IELTS misoli

- IELTS 6.0 uchun taxminan **1 000 soat** kerak
  - Kuniga 3 soat → 1 yil
  - Kuniga 6 soat → 6 oy (Post 189)
- Bu hisob-kitob har qanday ko'nikmaga tatbiq etilishi mumkin

## Online kurslarni tugatish

- Online kurslarni faqat **7%** tugatadi
- Yechim: do'st bilan birga o'qi, tugatmasangiz pul to'lashga kelishasiz (Post 98)
- Tashqi mas'uliyat intizomni kuchaytiradi

## Faol vs passiv o'rganish

- O'rganishning maqsadi — ma'lumot to'plash emas, balki **kerakli kalitlarni ajratib olish va qo'llash** (Post 246)
- 50 ta kitob o'qisangiz, kitob tavsiya qila olasiz. 100 ta o'qisangiz, kitoblar odamni o'zgartirmasligini tushunasiz — o'qish o'zgartiradi (Post 634)
- Hozirgi vaziyatingizga mos o'qi: talaba → samarali o'qish, xodim → ishni yaxshiroq qilish, musulmon → dinni amalda qo'llash (Post 634)

## Bilim — tugamas resurs

- Bilim — yagona **tugamas resurs**. Oltin, neft, gaz cheklidir (Post 611)
- Eng muhim bilimlar og'zaki uzatiladi — ustoz-shogird uslubida. Kitoblar buni to'liq almashtira olmaydi (Post 642)

## IT va texnologiya sohasida o'rganish

- Har bir kishi kamida 3 oylik IT kursi olishi kerak — dasturchi nima qilishini tushunish uchun (Post 258)
- 90% odam haqiqatan harakat qilsa, dasturlashni o'rgana oladi
- Avtomatlashtirish xavfi ostidagi kasblar: buxgalterlar, kassirlar, kutubxonachilar, bank xodimlari, operatorlar (Post 117)
- Eskirib qolmaslik uchun: keng o'qi + ijodkorlikni rivojlantir (Post 117)

---

*Qarang: [[Ta'lim va O'rganish]] · [[Ingliz Tili]] · [[Rasmiy Ta'lim Tanqidi]] · [[Kitob Tavsiyanomalar]] · [[Texnologiya va IT]]*

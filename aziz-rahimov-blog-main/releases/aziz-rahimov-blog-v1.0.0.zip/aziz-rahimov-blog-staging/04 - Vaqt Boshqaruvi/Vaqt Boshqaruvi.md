---
tags:
  - rivojlanish
  - amaliy
---

# Vaqt Boshqaruvi

Azizning vaqt falsafasi — uning eng ko'p takrorlanadigan mavzularidan biri. Vaqt sarflanmaydi — u konvertatsiya qilinadi: arzon (ko'ngil ochar) yoki qimmatli (bilim, pul, biznes) narsaga (Post 612).

## Asosiy tushunchalar

- Soatlik narxingizni biling. Oylik 3,000,000 UZS = soatiga 12,500 so'm. 110,000 so'mlik restoran = deyarli bir kunlik ish haqi
- 1000$ smartfon = hayotingizning 500–1000 soati
- Maqsad: $16,000/oy = 1 soat = $100 (Post 152)
- Agar vazifani $20 ga topshirish mumkin bo'lsa va vaqtingiz $20/soat bo'lsa — topshiring (Post 106)
- Batafsil: [[Vaqtingning Qiymati]]

## Ichki bo'limlar

- [[Diqqat va Limitlar]] — diqqatni himoya qilish, bildirishnomalarni o'chirish, Appblock/Forest, kundalik yuritish, imkoniyat qiymati
- [[Vaqt O'g'rilari va Asinxron Yashash]] — TV, befoyda suhbatlar, yangiliklar, Telegram hikoyalari + erta/kech yurish, tog' vs plyaj, kelajakdan qarz olish

## Bog'liq mavzular

- [[Vaqtingning Qiymati]]
- [[Limbik Kapitalizm]]
- [[Amaliy Maslahatlar va Vositalar]]
- [[Aziz Rahimov Blog - MOC]]

---
tags:
  - rivojlanish
  - amaliy
  - xronologiya
---

# Vaqt O'g'rilari va Asinxron Yashash

Vaqtni kim o'g'irlaydi — va bu o'g'rilardan qanday qochish mumkin.

## Vaqt O'g'rilari

- **Televizor** — sof isrof. "10 yil oldin TV ko'rmaslik 'vaqtim yo'q' degani edi; bugun esa 'pulimni isrof qilmayman' deganidir" (Post 34)
- **Befoyda suhbatlar** — siyosat, valyuta kursi, dunyo yangiliklari haqidagi gaplar (Post 145)
- **Foydali faktlar kanallar** — agar ma'lumot kasbingizni yaxshilamasa yoki odamlarni tushunishga yordam bermasa — bu isrof (Post 104)
- **Yangiliklar** — jurnalistlar ko'proq bosilish (click) uchun salbiy sarlavhalar yozadi. Yangilik o'qimang (Post 640). Haqiqatan muhim narsa bo'lsa — atrofingizdagi odamlar aytadi
- **Telegram hikoyalari** — siz izlamagan chalg'itish sizni topadi (Post 661)
- **Ijtimoiy tarmoq storylari** — Instagram, TikTok storylari diqqat kapkagidir

## Asinxron Yashash

Odamlar bilan bir vaqtda yashashni to'xtating — tiqilinchdan qoching:

- Ishga juda erta yoki juda kech boring — tiqilinchni chetlab o'ting (Post 229)
- Davlat idoralariga ular ochilmasidan oldin boring — navbatlarsiz
- Ish egalarini ertalab uchrating — ular ertalab yanada keskinroq va xushchaqchaq
- Soat 15:00 da qisqa uyqu oling
- **Tog'larni tanlang, plyajlardan emas** — arzonroq, odamsizroq, diqqat uchun yaxshiroq

## Kelajakdan Qarz Olish

- Bugungi vazifani kechiktirganingizda — kelajak o'zingizdan qarz olasiz. Qarz albatta qaytariladi (Post 638)
- Aksincha, kelajak o'zingizga sovg'alar bering: bilim, ish, sport
- O'tmishdagi o'zingiz bugungi yo'lingizni tanlagan. Hozirgi o'zingiz uni o'zgartira oladi (Post 231)

## Boshqalarning Vaqtini Hurmat Qilish

- Vaqtingizni hurmat qilmagan odam — sizni hurmat qilmaydi (Post 655)
- Uchrashuvlarga o'z vaqtida keling. Boshqalarning vaqtini o'g'irlamang
- Vaqt konvertatsiyasi: vaqt sarflanmaydi — u konvertatsiya qilinadi. Arzon (ko'ngil ochar) yoki qimmatli (bilim/pul/biznes) narsaga (Post 612)

## Bog'liq mavzular

- [[Diqqat va Limitlar]] — diqqatni himoya qilish va chegaralar
- [[Vaqtingning Qiymati]] — vaqtning pul ekvivalenti
- [[Limbik Kapitalizm]] — diqqat o'g'irlash mexanizmlari
- [[Vaqt Boshqaruvi]] — umumiy hub

---

*Manba: Aziz Rahimov blog postlari (Post 34, 104, 145, 229, 231, 612, 638, 640, 655, 661)*

---
tags:
  - rivojlanish
  - tafakkur
---

# Motivatsiya

Azizning asosiy fikri: motivatsiya — bu afsona. Harakat motivatsiyani tug'diradi, teskarisi emas.

## Motivatsiya Mifi
- "Eng kuchli motivatsiya ham ikki haftadan ortiq davom etmaydi" (Post 116)
- Motivatsiya boshlagandan KEYIN keladi, boshlashdan oldin emas
- Muvaffaqiyat haqidagi videolar vaqtinchalik turtki beradi — tez so'nadi
- "Hatto dangasa odam ham o'yin o'ynashga motivatsiya topadi" — haqiqiy motivatsiya = sizni chin dildan qiziqtiradigan narsani topish (Post 224)

## Motivatsiyaga Erishish Usullari
1. O'zingizni 21 kun majbur qiling — motivatsiya natijadan kelib chiqadi (Post 116)
2. Motivatsiyani kutib o'tirmang — avval boshlang
3. Kundalik odatlarni kuzatib borish uchun Loop ilovasidan foydalaning (Post 72)
4. Kundalik odatlar yarating: 5 bet o'qing, 1 ta foydali video ko'ring, 500 metr yugurmoq, 100 marta otjimaniya qilmoq
5. Shayx Muhammad Sodiq Muhammad Yusuf kayfiyatiga qaramay, har yili 10 tadan kitob yozgan

## Dangasalik — Post 203
- "Dangasalikni qanday yo'qotish mumkin? Hech qanday yo'l bilan." Miyangiz, tanangiz, nafsingiz va shayton — hammasi sizni dangasa ko'rishni xohlaydi
- TikTok, Instagram, YouTube, behuda yangiliklar e'tiboringiz uchun kurashmoqda
- Ajoyib postlar chiqadi, siz "zo'r yozibdi" deysiz — lekin uni AMALGA oshirasizmi?
- Yechim motivatsiyada emas — u intizom va tizimlarda ([[Intizom]])

## Motivatsiya Manbalari
- Juda muvaffaqiyatli odamlar (Zuckerberg, Musk) aslida ilhomlantirmaydi — ularning iqtidori millionda bitta (Post 85)
- Eng yaxshi ilhom: favqulodda natijalarga erishgan oddiy odamlar (Rosa Blumkin, Roman Aranin) — qarang [[Ilhomlantirivchi Hikoyalar]]
- Hech qanday tashqi motivator uzoq muddat ishlamaydi. "O'zingiz qaror qilmaguningizcha, sizni tashqaridan hech kim motivatsiya bera olmaydi" (Post 157)
- "Mening maqsadim: sizni har kuni biroz aqlliroq qilish" — Aziz (Post 157)

## Kitob
Jeff Heydenning "The Motivation Myth" ("Motivatsiya Mifi") — Aziz tomonidan tavsiya etilgan (Post 116)

---

Aloqador: [[Shaxsiy Rivojlanish]] | [[Intizom]] | [[Rezistans]] | [[Ilhomlantirivchi Hikoyalar]] | [[Kitob Tavsiyanomalar]]

Tags:   

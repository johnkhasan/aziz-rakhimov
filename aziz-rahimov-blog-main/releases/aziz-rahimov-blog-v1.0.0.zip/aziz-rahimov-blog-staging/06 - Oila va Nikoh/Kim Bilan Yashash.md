---
tags:
  - rivojlanish
  - tafakkur
  - amaliy
---

# Kim Bilan Yashash

Qarang: [[Ijtimoiy Munosabatlar]] | [[Muloqot San'ati]] | [[Shaxsiy Rivojlanish]] | [[Oila va Nikoh]]

---

## Energiya Kelajakni Belgilaydi — Post 169

- Atrofingizda bo'lgan odamlar sizning energiyangizni belgilaydi
- 5 yildan keyin atrofingizda bo'lganlar sizning karyera va hayot savollaringizni hal qilgan bo'ladi
- Samarali odamning yonida bo'lish = 15% ko'proq mahsuldorlik
- Zaharli odamning yonida bo'lish = 30% kam mahsuldorlik

## Sakkiz Metr Qoidasi — Post 643

Azizning kuzatishiga ko'ra, inson atrofidagi odamlar uning samaradorligiga bevosita ta'sir qiladi:

- Samarali odam yaqinida: **+15%** mahsuldorlik
- Zaharli odam yaqinida: **−30%** mahsuldorlik

Bu nisbat "Sakkiz metr qoidasi" deb ataladi — chunki taxminan 8 metrlik masofa ichidagi odamlar sizning holatingizdagi sezilarli o'zgarishni yuzaga keltiradi.

## "Meni Shundayligimcha Qabul Qil" — Post 131

- Bu ibora aslida bo'sh va ma'nosiz
- Haqiqiy do'stlar sizni o'sishga undaydi, holatingizni qabul qilmaydi
- "Qabul qil" deyuvchi odam sizning rivojlanishingizga to'siq bo'ladi

## Pessimistlarni Hayotdan Chiqarish — Post 205

Quyidagi turdagi do'stlarni hayotingizdan chiqaring:

- Pessimistlar
- Tartibsiz yashovchilar
- Maqsadsiz odamlar

Ular sizning energiyangizni so'rib oladi va oldinga borishingizga xalaqit beradi.

---

## Fikr Almashish — Post 132

- "Fikringizga qo'shilmayman" — hayotdagi eng katta saboqlar kelgan joy
- Har xil fikrlaydigan odamlar bilan vaqt o'tkazing
- Aziz xristianlar, ateistlar bilan ishladi va teologiyani chuqurroq tushundi
- Turlicha fikrlovchilardan qochmang — birinchi bahsda yutqazasiz, lekin bilim qozonasiz

---

## Odam Tanlash: G'oyaga Qarab — Post 220

Aziz quyidagi mezonlar bo'yicha **tanlamaydi**:

- Tug'ilgan joy
- Millat
- Jins
- Tashqi ko'rinish
- Din
- Boylik

Aziz quyidagi mezon bo'yicha **tanlaydi**:

- **G'oyalar** — chuqur, dalilga asoslangan fikrlar uning vaqtini oladi

Aziz quyidagilardan **qochadi**:

- Sayoz va o'ylamasdan gapiruvchilar
- Nafrat tarqatuvchilar
- G'iybat bilan shug'ullanuvchilar

---

Qarang: [[Muloqot San'ati]] | [[Shaxsiy Rivojlanish]] | [[Oila va Nikoh]]

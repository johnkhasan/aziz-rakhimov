---
tags:
  - oila
  - islom
  - tafakkur
---

# Qizni Tanlash Mezonlari

*Posts 65, 164, 158, 221 — Aziz Rahimov kanalidan*

## Asosiy Mezonlar (Posts 65, 164)

1. **Aqliy salohiyat va ma'lumot** — Poydevorli farzand tarbiya qila olishi kerak; repetitor yollashi, o'zi ishlashi va daromad qilishi lozim
2. **Hayolilik** — Uyatchan, kamtar; hayoli ona hayoli farzand tarbiya qiladi
3. **Namozxonlik** — Namoz o'qiyotganda barmog'ida sanab o'tirishini kuzating — bu uzoq yillik odatni ko'rsatadi
4. **Instagram/TikTok ga mukkasidan ketmaganlik** — Uy ekranida mashhur blogerlar bo'lsa — qizil bayroq

## Ahamiyat Bermasa Bo'ladiganlar

- **Hijob** — Vaqt o'tib o'zi progressga erishadi; majburlab bo'lmaydi
- **Tashqi ko'rinish** — Qadrlaymiz, lekin asosiy mezon qilib olmaymiz

## Eng Muhim O'lchov

Eng ishonchli taqqoslash nuqtasi — **o'z onangning fazilatlari**. Onangning yaxshi tomonlarini ro'yxat qilib, qidiruvni shu asosda olib bor.

## Qizni Qayerdan Topish (Post 158)

1. **O'quv markazlari** — Ingliz tili, arabcha, IT kurslari. Soat 17:00 — eng faol vaqt
2. **Kutubxona** (Alisher Navoiy kutubxonasi) — 14:00 dan keyin; jiddiy, o'quvchi odamlar
3. **Masjid** — Diniy yigitlar uchun; Hazrati Imom atrofi, soat 15:00–17:00

**Yondashish usuli:** To'g'ridan-to'g'ri emas — do'stining raqamini so'rang. Yonida qarindosh ayol bo'lsa, yanada yaxshi.

## Qizni Surishtirish (Post 221)

- Eng oson yo'l — uning yaqin do'stlarini bilish. **O'xshash qadriyatli qizlar bir-biriga yaqinlashadi**
- Yaqin do'sti yo'q bo'lsa — ogohlantiruvchi belgi: hammani ortiqcha gapirishi mumkin

## "Uy Yonayapti" Savoli (Post 69)

Uchrashuvda aqlli savol:

> "Uying yonayapti. 10 daqiqa oldin telefon jiringladi, yana 5 marta jiringladi. Harakatlaringizni bosqichma-bosqich tushuntiring."

Bu savol hayotidagi **ustuvorliklarini ochib beradi** — qanday qaror qabul qilishi, nimani birinchi o'ylashi.

---

Qarang: [[Oila va Nikoh]] | [[Yigitni Tanlash va Er-Xotin]] | [[Intizom]] | [[Ijtimoiy Munosabatlar]] | [[Aziz Rahimov Blog - MOC]]
